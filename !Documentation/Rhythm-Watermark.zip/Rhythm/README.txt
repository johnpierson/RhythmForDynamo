Screen Watermark
    Screen Watermark is an application that overlays an image over the desktop
and can act as a flexible watermark on videos or pictures taken directly
off the screen. The main use is for adding in a watermark when your video
or screen capture software does not support watermarks correctly or at all.

Configuration file is config.xml
    You can change the default starting position.

Key Bindings:
W: one pixel up
S: one pixel down
A: one pixel left
D: one pixel right

TGFH: ten pixels
IKJL: twenty pixels

N: 10% more translucent
M: 10% less translucent

X: Exit